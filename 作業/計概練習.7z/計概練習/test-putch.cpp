#include<stdio.h>
#include<conio.h>
int main()
{
	putch(getch());
	
	return 0;
}
