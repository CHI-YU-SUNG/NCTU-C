#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int main()
{
	char ch;
	int i;
	for(i=1;;i++)
	{
		ch=getche();
		system("cls");
		printf("%c",ch);
	}
	
	
	return 0;
}
