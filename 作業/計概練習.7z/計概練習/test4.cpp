#include<stdio.h>
#include<math.h>
int main()
{
//�}�C 
	int a[6],i;
	
		for(i=5;i>=0;i--)
		{
			printf("a[%d]=\n",i);
			scanf("%d",&a[i]);
			
		}

}
