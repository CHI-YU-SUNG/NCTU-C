#include<stdio.h>
int main()
{
	int x=1,y=5,m;
		
		m=(++x) ++ +y;
		printf("x=%d\n",x);
		printf("y=%d\n",y);
		printf("m=%d",m);	
	return 0;
} 
