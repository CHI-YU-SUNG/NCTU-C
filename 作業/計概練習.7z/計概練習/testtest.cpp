#include <stdio.h>
#include <conio.h>
#

int main()
{
	int a;
	char ch1;
	clrscr ();
	printf("%d",a);
	return 0;
} 
