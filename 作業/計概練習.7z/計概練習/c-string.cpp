#include<stdio.h>
#include<string.h>
int main()
{
	char s1[5] = "test";
	char *s2 = "test1";
	printf("%s \n%s",s1,s2);
	
	
	return 0;
} 
