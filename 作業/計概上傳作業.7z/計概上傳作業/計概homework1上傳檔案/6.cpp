#include<stdio.h> 
#include<conio.h>

int main()
{
	int fid1=0,fid2=1,fid3=1;
		printf("fid1=%d\n",fid1=0);
		printf("fid2=%d\n",fid2=1);
		printf("fid3=%d\n",fid3=1);
		printf("fid2=%d\n",fid2+=fid3);
		printf("fid3=%d\n",fid3+=fid2);
		printf("fid2=%d\n",fid2+=fid3);
		printf("fid3=%d\n",fid3+=fid2);
		printf("fid2=%d\n",fid2+=fid3);
		printf("fid3=%d\n",fid3+=fid2);
		printf("fid2=%d\n",fid2+=fid3);
		printf("fid3=%d\n",fid3+=fid2);
		printf("fid2=%d\n",fid2+=fid3);
	
	getch();	
	return 0;
}
