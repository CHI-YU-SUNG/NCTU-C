#include<stdio.h>
#include<conio.h>

int main()
{
	float a=6.75,PI=3.14159;
	printf("the diameter is=%10.5f\nthe circumference is=%10.5f\nthe area is=%10.5f\n",2*a,2*a*PI,a*a*PI);
	
	getch();
	return 0;
}
